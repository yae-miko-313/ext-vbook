document.addEventListener('DOMContentLoaded', () => {
  const tokenInput = document.getElementById('tokenInput');
  const copyBtn = document.getElementById('copyBtn');
  const statusEl = document.getElementById('status');

  // Khôi phục token từ storage khi mở popup
  chrome.storage.local.get(['comnguoi_token'], (result) => {
    if (result.comnguoi_token) {
      tokenInput.value = result.comnguoi_token;
      // Clear badge after the user has seen the token
      chrome.action.setBadgeText({ text: "" });
    }
  });

  // Lắng nghe sự kiện click nút Copy
  copyBtn.addEventListener('click', () => {
    if (!tokenInput.value) return;
    
    // Copy vào clipboard
    navigator.clipboard.writeText(tokenInput.value).then(() => {
      // Hiển thị thông báo thành công
      statusEl.classList.remove('hidden');
      copyBtn.textContent = 'Đã Copy!';
      
      // Ẩn thông báo sau 2 giây
      setTimeout(() => {
        statusEl.classList.add('hidden');
        copyBtn.textContent = 'Copy Token';
      }, 2000);
    }).catch(err => {
      console.error('Lỗi khi copy: ', err);
      // Fallback
      tokenInput.select();
      document.execCommand('copy');
      statusEl.classList.remove('hidden');
      setTimeout(() => {
        statusEl.classList.add('hidden');
      }, 2000);
    });
  });
});
