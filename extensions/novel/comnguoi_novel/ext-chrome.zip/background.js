const TARGET_URLS = ["*://*.truyendichmienphi.com/*"];

chrome.webRequest.onSendHeaders.addListener(
  (details) => {
    if (details.requestHeaders) {
      for (let header of details.requestHeaders) {
        if (header.name.toLowerCase() === 'authorization' && header.value.startsWith('Bearer ')) {
          console.log("Token caught:", header.value);
          
          // Save token to local storage
          chrome.storage.local.set({ comnguoi_token: header.value });
          
          // Update extension badge to show it caught a token
          chrome.action.setBadgeText({ text: "✓" });
          chrome.action.setBadgeBackgroundColor({ color: "#4CAF50" });
          break;
        }
      }
    }
  },
  { urls: TARGET_URLS },
  ["requestHeaders", "extraHeaders"]
);
