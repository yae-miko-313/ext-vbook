load("config.js");

function execute() {
  return Response.success([
    {
      title: "Mới cập nhật",
      input: API_URL + "/api/novels/latest?category_type=male&limit=20&page=",
      script: "gen.js"
    },
    {
      title: "Xem nhiều",
      input: API_URL + "/api/novels/top-read?category_type=male&limit=20&page=",
      script: "gen.js"
    },
    {
      title: "Đánh giá cao",
      input: API_URL + "/api/novels/top-rated?category_type=male&limit=20&page=",
      script: "gen.js"
    }
  ]);
}
