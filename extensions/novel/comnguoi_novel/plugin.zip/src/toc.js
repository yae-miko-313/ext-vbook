load("config.js");

function execute(url) {
  var slug = url;
  if (url.indexOf("http") === 0) {
    var parts = url.split("/");
    slug = parts[parts.length - 1];
  }

  var response = fetch(API_URL + "/api/novels/" + slug + "/chapters?limit=10000&page=1", {
    headers: {
      "User-Agent": "okhttp/4.12.0"
    }
  }).json();
  if (!response || !response.results) return Response.error("Lỗi khi tải danh sách chương");

  response.results.sort(function(a, b) {
    return a.chapter_number - b.chapter_number;
  });

  var list = response.results.map(function(item) {
    var title = item.title ? String(item.title) : ("Chương " + item.chapter_number);
    if (title.toLowerCase().indexOf("chương") === -1 && title.toLowerCase().indexOf("ngoại truyện") === -1) {
      title = "Chương " + item.chapter_number + ": " + title;
    }
    return {
      name: title,
      url: API_URL + "/api/novels/" + slug + "/chapter/" + item.chapter_number,
      host: BASE_URL
    };
  });

  return Response.success(list);
}
