load("config.js");

function normalizeDetailUrl(url) {
  if (!url) return "";

  var cleanUrl = String(url).replace(/[?#].*$/, "").replace(/\/+$/, "");
  if (cleanUrl.indexOf("http") !== 0) {
    if (cleanUrl.indexOf("/") === 0) {
      cleanUrl = BASE_URL + cleanUrl;
    } else {
      cleanUrl = BASE_URL + "/" + cleanUrl;
    }
  }

  return cleanUrl;
}

function getSlugFromUrl(url) {
  var cleanUrl = normalizeDetailUrl(url);
  var match = cleanUrl.match(/\/truyen\/([^\/]+)$/);
  if (match && match[1]) return match[1];

  var parts = cleanUrl.split("/");
  return parts[parts.length - 1];
}

function execute(url) {
  var sourceUrl = normalizeDetailUrl(url);
  var slug = getSlugFromUrl(sourceUrl);
  var canonicalUrl = BASE_URL + "/truyen/" + slug;

  var response = fetch(API_URL + "/api/novels/" + slug, {
    headers: {
      "User-Agent": "okhttp/4.12.0"
    }
  }).json();
  
  if (!response || !response.id) return Response.error("Lỗi tải thông tin truyện");

  var genres = [];
  if (response.types && response.types.length > 0) {
    genres = response.types.map(function(g) { 
      return {
        title: g.name,
        input: "",
        script: "gen.js"
      }; 
    });
  } else if (response.genres && response.genres.length > 0) {
    genres = response.genres.map(function(g) { 
      return {
        title: g.name,
        input: "",
        script: "gen.js"
      }; 
    });
  }

  return Response.success({
    name: response.title,
    cover: "https://s3-hcm-r2.s3cloud.vn/tdmp/" + response.poster_url,
    author: response.author_name || "Đang cập nhật",
    description: response.description || "",
    detail: "Tác giả: " + (response.author_name || "N/A") + "<br>Lượt xem: " + (response.view_count || 0) + "<br>Tình trạng: " + (response.status === "completed" ? "Hoàn thành" : "Đang ra"),
    host: BASE_URL,
    ongoing: response.status !== "completed",
    genres: genres,
    link: canonicalUrl,
    url: canonicalUrl
  });
}
