load("config.js");
load("crypto_ole.js");

function slugify(text) {
  return text
    .toString()
    .toLowerCase()
    .replace(/\s+/g, "-")
    .replace(/[^\w\-]+/g, "")
    .replace(/\-\-+/g, "-")
    .replace(/^-+/, "")
    .replace(/-+$/, "");
}

function execute(key, page) {
  if (!page) page = "1";
  
  var response = fetch(API_URL + "/api/novels/search", {
    headers: {
      "User-Agent": "okhttp/4.12.0"
    },
    queries: {
      limit: 20,
      page: page,
      q: slugify(key)
    }
  }).json();

  if (!response || !response.results) return Response.error("Lỗi khi tìm kiếm");

  var list = response.results.map(function(item) {
    return {
      name: item.title,
      link: item.slug,
      cover: "https://s3-hcm-r2.s3cloud.vn/tdmp/" + item.poster_url,
      description: item.author_name || item.status,
      host: BASE_URL
    };
  });

  var next = parseInt(page) < response.totalPages ? (parseInt(page) + 1).toString() : "";
  return Response.success(list, next);
}
