load("config.js");

function execute(url, page) {
  if (!page) page = "1";
  
  var queryUrl = url;
  if (url.match(/page=$/)) {
    queryUrl = url + page;
  } else if (url.indexOf("?") !== -1) {
    queryUrl = url + "&page=" + page;
  } else {
    // Some old configs might not have trailing slash or query, but standard is append ?page=
    var separator = url.indexOf("?") !== -1 ? "&" : "?";
    queryUrl = url + separator + "page=" + page;
  }

  var response = fetch(queryUrl, {
    headers: {
      "User-Agent": "okhttp/4.12.0"
    }
  }).json();
  
  if (!response) return Response.error("Lỗi khi tải danh sách truyện");

  var items = response;
  if (response.results) {
    items = response.results;
  }
  
  if (!items || items.length === 0) {
    return Response.error("Không có dữ liệu");
  }

  var list = items.map(function(item) {
    return {
      name: item.title,
      link: item.slug,
      cover: "https://s3-hcm-r2.s3cloud.vn/tdmp/" + item.poster_url,
      description: item.author_name || item.status,
      host: BASE_URL
    };
  });

  var next = "";
  if (response.totalPages) {
    next = parseInt(page) < response.totalPages ? (parseInt(page) + 1).toString() : "";
  } else if (items.length > 0) {
    next = (parseInt(page) + 1).toString();
  }

  return Response.success(list, next);
}
