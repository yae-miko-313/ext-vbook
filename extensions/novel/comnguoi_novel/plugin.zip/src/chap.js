load("config.js");
load("crypto_ole.js");

function execute(url) {
  var apiEndpoint = url;

  if (url.indexOf("/api/novels/") === -1) {
    var urlStr = url.replace(/^(https?:\/\/)?[^\/]+\//, "");
    var parts = urlStr.split("/");
    var chapterStr = parts.pop();
    var novelSlug = parts.pop();
    if (novelSlug === "truyen" || novelSlug === "chapter") novelSlug = parts.pop();
    var chapterNumber = chapterStr.replace(/[^\d]/g, "");
    apiEndpoint = API_URL + "/api/novels/" + novelSlug + "/chapter/" + chapterNumber;
  }

  var PASSPHRASE = "z4x8vog2a13vz4x8vog2a13v";

  var headers = {
    "User-Agent": "okhttp/4.12.0"
  };
  var token = getToken();
  if (token) {
    headers["Authorization"] = token.startsWith("Bearer") ? token : "Bearer " + token;
  }

  var response = fetch(apiEndpoint, {
    headers: headers
  });

  if (response.ok) {
    var data = response.json();
    if (data && data.content) {
      var contentStr = String(data.content).replace(/\s+/g, "");
      var decodedText = "";

      try {
        var decrypted = CryptoJS.AES.decrypt(contentStr, PASSPHRASE);
        try {
          decodedText = decrypted.toString(CryptoJS.enc.Utf8);
        } catch (utf8Error) {
          var hex = decrypted.toString(CryptoJS.enc.Hex);
          decodedText = "";
          for (var i = 0; i < hex.length; i += 2) {
            var byteValue = parseInt(hex.substr(i, 2), 16);
            if (byteValue !== 0) decodedText += String.fromCharCode(byteValue);
          }
          try { decodedText = decodeURIComponent(escape(decodedText)); } catch (e) {}
        }
      } catch (e) {
        return Response.error("Lỗi giải mã chương: " + e.message);
      }

      var cleanedText = stripTrailingNoise(decodedText);
      if (cleanedText && cleanedText.length > 0) {
        decodedText = cleanedText;
      }

      if (!decodedText) {
        return Response.error("Không thể giải mã nội dung chương (kết quả rỗng).");
      }

      return Response.success(formatContent(decodedText));
    }
  } else if (response.status === 401 || response.status === 403) {
    return Response.error("Chương này yêu cầu cấu hình Token App hợp lệ trong config.js để đọc!");
  }

  return Response.error("Không thể lấy được nội dung chương.");
}

function formatContent(text) {
  var lines = text.split("\n");
  lines.reverse(); // Api trả về các dòng bị đảo ngược!
  return lines.join("<br>");
}

function stripTrailingNoise(text) {
  if (!text) return "";

  var lines = String(text).split("\n");
  while (lines.length > 0 && !lines[lines.length - 1].trim()) {
    lines.pop();
  }
  while (lines.length > 0 && isLikelyBinaryLine(lines[lines.length - 1])) {
    lines.pop();
  }
  return lines.join("\n").trim();
}

function isLikelyBinaryLine(line) {
  if (!line) return false;

  var controlChars = line.match(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F-\u009F]/g);
  if (controlChars && controlChars.length > 0) {
    return true;
  }

  if (line.length < 16) {
    return false;
  }

  var visibleChars = line.match(/[A-Za-zÀ-ỹ0-9 ]/g);
  if (!visibleChars) {
    return true;
  }

  return visibleChars.length / line.length < 0.75;
}
