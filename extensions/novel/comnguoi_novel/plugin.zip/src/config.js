var BASE_URL = "https://truyendichmienphi.com";
var API_URL = "https://api.truyendichmienphi.com";

// USER ĐIỀN TOKEN VÀO ĐÂY (Token có dạng Bearer ...)
// Lấy bằng cách login vào web, mở DevTools (F12) -> Application -> Local Storage -> tìm token.
// var USER_TOKEN = ""; // Removed to avoid overwriting injected config

function getToken() {
  try {
    if (typeof USER_TOKEN !== "undefined" && USER_TOKEN) {
      return USER_TOKEN;
    }
  } catch (e) {}
  
  return USER_TOKEN;
}
