load('config.js');

// TRACK — Stream URL Resolver
// Input: URL trang xem phim /xem/{id}-sv{n}-ep{n}/
// Output: { data, type, host }

var DEFAULT_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "Referer": BASE_URL + "/"
};

function execute(url) {
    url = normalizeUrl(url);

    var response = fetch(url, { headers: DEFAULT_HEADERS });
    if (!response.ok) {
        return Response.success({ data: url, type: "auto", host: BASE_URL });
    }

    var html = response.text();
    if (!html || html.length < 100) {
        return Response.success({ data: url, type: "auto", host: BASE_URL });
    }

    // Extract video URL directly from player_aaaa with string extraction
    // Avoid JSON parsing issues with escaped slashes in Rhino
    var videoUrl = "";
    var from = "";

    // Find player_aaaa block
    var pdMatch = html.match(/var\s+player_aaaa\s*=\s*\{[^}]+\}/i);
    if (pdMatch) {
        var block = pdMatch[0];

        // Extract "url":"..." value (handles escaped quotes and slashes)
        var urlMatch = block.match(/"url"\s*:\s*"([^"]+)"/i);
        if (urlMatch) {
            videoUrl = urlMatch[1];
            // Unescape JSON escaped slashes
            videoUrl = videoUrl.replace(/\\\//g, "/");
        }

        // Extract "from":"..." value
        var fromMatch = block.match(/"from"\s*:\s*"([^"]+)"/i);
        if (fromMatch) {
            from = fromMatch[1].toLowerCase();
        }

        // Handle encrypt=1 (URL encoded) - matches both "encrypt":1 and "encrypt":"1"
        var encMatch = block.match(/"encrypt"\s*:\s*(?:"?(\d)"?)/i);
        if (encMatch && encMatch[1] === "1" && videoUrl) {
            try { videoUrl = decodeURIComponent(videoUrl); } catch (e) {}
        }
    }

    // Fallback: return input URL
    if (!videoUrl) {
        return Response.success({ data: url, type: "auto", host: BASE_URL });
    }

    // Determine type: iframe for archive.org or explicit iframe sources
    var streamType = "auto";
    if (videoUrl.indexOf("archive.org/") >= 0 || from === "iframe") {
        streamType = "iframe";
    }

    return Response.success({
        data: videoUrl,
        type: streamType,
        host: BASE_URL,
        timeSkip: []
    });
}


